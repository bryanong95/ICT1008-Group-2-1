import nodes as a
import edges
import pathSearch
import networkx as nx
import matplotlib.pyplot as plt

pp = nx.MultiDiGraph()
pp = a.insertAllNodes(pp)
pp = a.insertHDBNodes(pp)
pp = edges.insertAllEdges(pp)

punggol = nx.MultiDiGraph()
punggol = a.insertHDBNodes(punggol)

#print(pp.nodes.data())
#print(nx.is_connected(punggol))


################################### TEST DIJKSTRA #########################################

#test = pathSearch.Route(punggol, "NE17", "821162A", "fastest")
#nodes, edges = test.get_data()


# print(nodes)
# print(edges)
# storing the whole long and lat
data = []
whole = pp.nodes.data()
#printing the nodes Longtitudes latit
for n in whole:
    position = []
    position.append(n[1]["pos"][0])
    position.append(n[1]["pos"][1])
    data.append(position)

    #position.append(n)

   # data = position['pos']
    # position.append(n['pos'])
    #data.append(position)

    #data.append(Person())
    #print(n['pos'])


#print(data)

# hdb values
hdb = punggol.nodes.data()
name = []
for n in hdb:
    name.append(n[1]["name"])


print(name)
#print(name[0][0])
###########################################################################################

pos = nx.get_node_attributes(punggol, 'pos')
nx.draw(punggol, pos, with_labels=True)
