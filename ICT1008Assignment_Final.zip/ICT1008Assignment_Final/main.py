from flask import Flask, render_template, request, jsonify
from flask_bootstrap import Bootstrap
import nodes
import edges
import pathSearch
import networkx as nx
import html

pp = nx.MultiDiGraph()
pp = nodes.insertAllNodes(pp)
pp = nodes.insertHDBNodes(pp)
pp = edges.insertAllEdges(pp)

pung = nx.MultiDiGraph()
pung = nodes.insertHDBNodes(pung)

punggol = nx.MultiDiGraph()
punggol = nodes.insertAllNodes(punggol)
punggol = edges.insertAllEdges(punggol)

# app = Flask(__name__)

# template = html
app = Flask(__name__, static_url_path='/static')
Bootstrap(app)

# whole = pp.nodes.data()
# # storing the whole long and lat
data = []
whole = pp.nodes.data()
# # printing the nodes Longtitudes latit
for n in whole:
    position = []
    position.append(n[1]["pos"][0])
    position.append(n[1]["pos"][1])
    data.append(position)

# print(data)

# hdb values
hdb = []
id = []
result_str = []
hh = pung.nodes.data()

for n in hh:
    pos = []
    pos.append(n[1]["pos"][0])
    pos.append(n[1]["pos"][1])
    hdb.append(pos)
    id.append(n[0])


name = []
for n in hh:
    name.append(n[1]["name"])


# print(n[1]["pos"])


# @app.route('/', methods=['GET'])  # root directory
# def index():
#     destination = name
#     return render_template('index.html', destination=destination, methods=['GET'], data=data, hdb=hdb, i=1)


@app.route('/', methods=['GET'])  # root directory
def index():
    destination = name

    position = []
    resulttypefinal = []
    resultservicefinal = []
    resultnamefinal = []
    result_str=[]
    temp_str = ""
    totaltraveltime = 0
    totaltraveldis = 0.0
    #print(position)
    start =[]
    end = []
    totaltime =[]
    totaldis =[]

    result_str.append("Starting point: Punggol Mrt Station")
    #result_str = result_str.replace("\n", "<br />\n")

    profile = request.args.get('profile')
    dest = request.args.get('destination', type=int)  # retrieving the value of key call destination
    test = ""
    if profile is not None and dest is not None:
        test = pathSearch.Route(punggol, "NE17", id[dest], profile)
        nodes, edges = test.get_data()
        for n in nodes:
            ll = []
            resultname = []
            ll.append(n["pos"][0])
            ll.append(n["pos"][1])
            position.append(ll)
            resultname.append(n["name"])
            resultnamefinal.append(resultname)
        temp_str = "Ending point:"
        temp_str += destination[dest]
        result_str.append(temp_str)
        #edges
        resulttype = []
        for e in edges:
            totaltraveltime += int(e[0]['time'])
            totaltraveldis += float(e[0]['distance'])


        temp_str = "Total travel distance: "
        temp_str += str(round(totaltraveldis,2)) + ' km'
        result_str.append(temp_str)
        result_str.append('Total travel time: ' + str(totaltraveltime) + ' min')
        totaltime.append(totaltraveltime)
        totaldis.append(totaltraveldis)

        startnode = nodes[0]
        endnode = nodes[1]
        lastEdges = []
        for e in edges[0]:
            lastEdges.append(e['service'])
        for i in range(1,len(edges)):
            same = True
            if len(edges[i]) == len(lastEdges):
                for e in edges[i]:
                    if e['service'] not in lastEdges:
                        same = False
                if same:
                    endNode = nodes[i+1]
                else:
                    result_str.append(startnode['name'] + " -> " + endnode['name'])
                    result_str.append(edges[i-1][0]['type'])
                    temp_str=""
                    for s in lastEdges:
                        temp_str += s + " "
                    result_str.append(temp_str)
                    lastEdges.clear()
                    for e in edges[i]:
                        lastEdges.append(e['service'])
                    startnode = endnode
                    endnode = nodes[i+1]
            else:
                result_str.append(startnode['name'] + " -> " + endnode['name'])
                result_str.append(edges[i-1][0]['type'])
                temp_str = ""
                for s in lastEdges:
                    temp_str += s + " "
                result_str.append(temp_str)
                lastEdges.clear()
                for e in edges[i]:
                    lastEdges.append(e['service'])
                startnode = endnode
                endnode = nodes[i + 1]

        result_str.append(startnode['name'] + " -> " + endnode['name'])
        result_str.append(edges[-1][0]['type'])
        result_str.append(lastEdges[0])


        # # print(position)
        # print(nodes)
        # print(edges)
        # print(resultnamefinal)
        # print(resulttypefinal)
        # print(result_str)
        # #print(totaltraveltime)
        nodes.clear()
        edges.clear()
    return render_template('index.html', destination=destination, methods=['GET'], data=data, hdb=hdb, i=1,
                           position=position, id=id,result_str=result_str, totaltime=totaltime,totaldis=totaldis)


def getval(names):
    print('names', names)


@app.route('/pass_val', methods=['POST'])
def pass_val():
    names = request.args.get('value')
    getval(names)
    return jsonify({'reply': 'success'})


# quick check : only if this file is run directly
if __name__ == "__main__":
    app.run(debug=True)
