INFINITY = 99999
class Route:
    graph = None
    start = None
    end = None
    time = {}
    distance = {}
    transfers = {}
    predecessor = {}
    path = []
    edges = []
    nodes_final = []
    edges_final = []

    def __init__(self, g, s, e, method):
        self.graph = g
        self.start = s
        self.end = e


        # Determine which function to use based on method
        if method == "fastest":
            # Run the dijkstra
            self.fastest_path_map()

            # Get the path
            self.path = self.get_path()

            # Get the edges in the path
            self.edges = self.get_edges()

            # Print (just for testing purposes)

            self.get_final_data()

        elif method == "shortest":
            # Run the dijkstra
            self.shortest_path_map()

            # Get the path
            self.path = self.get_path()

            # Get the edges in the path
            self.edges = self.get_edges()

            # Print (just for testing purposes)
            self.get_final_data()

        elif method == "fewest":
            # Run the dijkstra
            self.fewest_path_map()

            # Get the path
            self.path = self.get_path()

            # Get the edges in the path
            self.edges = self.get_edges()

            # Print (just for testing purposes)
            self.get_final_data()


    def get_data(self):
        return self.nodes_final, self.edges

    # def get_final_data(self):
    #
    #
    #     if self.time[self.end] != INFINITY:
    #         # Print out the edges
    #         for edge in self.edges:
    #             halfpath1 = []
    #             for e in edge:
    #
    #                 if e['type'] == 'bus':
    #                     if len(used_bus) == 0:
    #                         used_bus.append(e['service'])
    #                         halfpath1.append(e)
    #                     else:
    #                         if e['service'] in used_bus:
    #                             halfpath1.append(e)
    #                         else:
    #                             used_bus.append(e['service'])
    #                 else:
    #                     halfpath1.append(e)
    #
    #             self.edges_final.append(halfpath1)
    #         # return paththough,time[end],distance[end]
    #         # Print the time and distance
    #


    def get_final_data(self):
        FilterdBus = []  # list of all the bus for the journey
        toDelete = []  # to delete all the bus services that are not needed for the journey
        addbusStop = []  # list of all the bus services for the bus stop
        asdf = False  # if FilteredBus[] is empty, then fill it with all the bus services of that bus stop.

        for edge in range(len(self.edges)):

            # add all the services for that bus stop into addbusStop[]
            for x in self.edges[edge]:
                addbusStop.append(x['service'])

            # if there are no similarities between the filteredBus and the addbusStop,
            # means the person has to transfer in that bus stop
            diff = [r for r in addbusStop if r not in FilterdBus]
            if (len(diff) == len(addbusStop)):
                FilterdBus.clear()

            # if the FilteredBus is empty, proceed to fill that with all the bus services in the current bus stop
            if len(FilterdBus) == 0:
                asdf = True

            for e in range(len(self.edges[edge])):

                # adding current bus services if filteredBus is empty
                if self.edges[edge][e]['type'] == 'bus' and asdf:
                    FilterdBus.append(self.edges[edge][e]['service'])

                # if there is new bus service in the bus stop that doesn't continue from the prev journey,
                # delete that bus service from filteredBus
                if (self.edges[edge][e]['type']) == 'bus':
                    if self.edges[edge][e]['service'] not in FilterdBus:
                        toDelete.append(e)

            asdf = False  # now that fileterdBus is not empty anymore, change it back to False
            filtered = [i for j, i in enumerate(self.edges[edge]) if
                        j not in toDelete]  # delete all the bus stops recorded within toDelete[]
            self.edges[edge] = filtered  # assign modified list of edges to the original list of edges
            toDelete.clear()
            addbusStop.clear()
        for n in self.path:
            self.nodes_final.append(self.graph.nodes[n])

        # return edges

    def get_path(self):
        final_path = []  # Final path from start to end

        # Start from the end node
        current_node = self.end
        while current_node != self.start:

            try:
                # Store the node into the finalPath array and go to the predecessor node
                final_path.insert(0, current_node)
                current_node = self.predecessor[current_node]
            except KeyError:
                print("Failed to find path")
                return None

        # Insert the start node into the finalPath
        final_path.insert(0, self.start)

        return final_path


    def get_edges(self):
        final_edges = []  # Final edges information

        # Getting all the edges in between nodes
        for i in range(len(self.path) - 1):

            edges_list = []
            edges = self.graph.get_edge_data(self.path[i], self.path[i + 1])

            # For all edges between 2 nodes in the final path
            for key in edges.keys():

                if len(edges_list) == 0:
                    edges_list.append(edges[key])
                    continue

                # If they are the shortest time edge then add them to the edges list
                if edges[key]['time'] == edges_list[0]['time']:
                    edges_list.append(edges[key])
                # If they are the new shortest edge then reset edge list and put in the new shortest time edge
                elif edges[key]['time'] < edges_list[0]['time']:
                    edges_list = []
                    edges_list.append(edges[key])

            # Add the edge list in the finalEdges
            final_edges.append(edges_list)
        return final_edges


    def fastest_path_map(self):
        unvisited_nodes = []    # List of nodes that have yet to be visited

        # Setting all nodes to 99999 at the beginning and adding the nodes to the list
        for node in self.graph.nodes.data():
            unvisited_nodes.append(node[0])
            self.time[node[0]] = INFINITY
            self.distance[node[0]] = INFINITY

        # Set root node distance as 0
        self.time[self.start] = 0
        self.distance[self.start] = 0

        # Iterate as long as there are unvisited nodes
        while unvisited_nodes:
            # For storing the minimum distance node
            min_node = None

            # Find the minimum node
            for node in unvisited_nodes:

                # If first iteration then just set the minimum node
                if min_node is None:
                    min_node = node
                # Else check if this node is smaller than the current minimum
                elif self.time[node] < self.time[min_node]:
                    min_node = node

            # Get all the edges in the minimum node and see if it is smaller than the existing entry in shortest time
            for edge in self.graph.edges(min_node):

                # Get the time and distance between the 2 nodes
                edge_data = self.graph.get_edge_data(edge[0], edge[1])
                t = INFINITY
                d = INFINITY

                for e in edge_data:
                    if float(edge_data[e]['time'])<t:
                        t = float(edge_data[e]['time'])
                        d = float(edge_data[e]['distance'])

                # Replace if it is smaller (This is the dijkstra part where longer paths are replaced by shorter paths)
                if t + self.time[min_node] < self.time[edge[1]]:
                    self.time[edge[1]] = t + self.time[min_node]
                    self.distance[edge[1]] = d + self.distance[min_node]
                    self.predecessor[edge[1]] = min_node
                    unvisited_nodes.append(edge[1])

            # Node has been visited so it can be removed from the list
            unvisited_nodes.remove(min_node)



    def shortest_path_map(self):
        unvisited_nodes = []     # List of nodes that have yet to be visited

        # Setting all nodes to 99999 at the beginning and adding the nodes to the list
        for node in self.graph.nodes.data():
            unvisited_nodes.append(node[0])
            self.distance[node[0]] = INFINITY
            self.time[node[0]] = INFINITY

        # Set root node distance as 0
        self.distance[self.start] = 0
        self.time[self.start] = 0

        # Iterate as long as there are unvisited nodes
        while unvisited_nodes:
            # For storing the minimum distance node
            min_node = None

            # Find the minimum node
            for node in unvisited_nodes:
                # If first iteration then just set the minimum node
                if min_node is None:
                    min_node = node
                # Else check if this node is smaller than the current minimum
                elif self.distance[node] < self.distance[min_node]:
                    min_node = node

            # Get all the edges in the minimum node and see if it is smaller than the existing entry in shortest time
            for edge in self.graph.edges(min_node):

                # Get the time and distance between the 2 nodes
                edge_data = self.graph.get_edge_data(edge[0], edge[1])
                t = INFINITY
                d = INFINITY

                for e in edge_data:
                    if float(edge_data[e]['distance']) < d:
                        t = float(edge_data[e]['time'])
                        d = float(edge_data[e]['distance'])

                # Replace if it is smaller (This is the dijkstra part where longer paths are replaced by shorter paths)
                if d + self.distance[min_node] < self.distance[edge[1]]:
                    self.distance[edge[1]] = d + self.distance[min_node]
                    self.time[edge[1]] = t + self.time[min_node]
                    self.predecessor[edge[1]] = min_node
                    unvisited_nodes.append(edge[1])

            # Node has been visited so it can be removed from the list
            unvisited_nodes.remove(min_node)


    def fewest_path_map(self):
        unvisited_nodes = []     # List of nodes that have yet to be visited
        pre_edges = {}
        pre_edges[self.start] = []

        # Setting all nodes to 99999 at the beginning and adding the nodes to the list
        for node in self.graph.nodes.data():
            unvisited_nodes.append(node[0])
            self.distance[node[0]] = INFINITY
            self.time[node[0]] = INFINITY
            self.transfers[node[0]] = INFINITY

        # Set root node distance as 0
        self.distance[self.start] = 0
        self.time[self.start] = 0
        self.transfers[self.start] = 0

        # Iterate as long as there are unvisited nodes
        while unvisited_nodes:
            # For storing the minimum distance node
            min_node = None

            # Find the minimum node
            for node in unvisited_nodes:
                # If first iteration then just set the minimum node
                if min_node is None:
                    min_node = node
                # Else check if this node is smaller than the current minimum
                elif self.transfers[node] < self.transfers[min_node]:
                    min_node = node

            # Get all the edges in the minimum node and see if it is smaller than the existing entry in shortest time
            for edge in self.graph.edges(min_node):
                if min_node != edge[0]:
                    continue
                # Get the time and distance between the 2 nodes
                edge_data = self.graph.get_edge_data(edge[0], edge[1])
                t = INFINITY
                d = INFINITY

                for e in edge_data:
                    if float(edge_data[e]['distance']) < d:
                        t = float(edge_data[e]['time'])
                        d = float(edge_data[e]['distance'])

                s = []
                trans = 0
                # Get the number of services which intersect with the previous
                for e in edge_data:
                    if edge[0] not in pre_edges:
                        continue
                    if edge_data[e]['service'] in pre_edges[edge[0]]:
                        s.append(edge_data[e]['service'])
                # If there are no services which intersect, consider it as number of transfers += 1
                if len(s) == 0:
                    for e in edge_data:
                        s.append(edge_data[e]['service'])
                    trans = 1

                # Replace if less transfers (This is the dijkstra part where longer paths are replaced by shorter paths)
                if (trans + self.transfers[min_node] < self.transfers[edge[1]]) or (trans + self.transfers[min_node] == self.transfers[edge[1]] and d + self.distance[min_node] < self.distance[edge[1]]):
                    self.distance[edge[1]] = d + self.distance[min_node]
                    self.time[edge[1]] = t + self.time[min_node]
                    self.predecessor[edge[1]] = min_node
                    pre_edges[edge[1]] = s
                    self.transfers[edge[1]] = self.transfers[edge[0]] + trans
                    unvisited_nodes.append(edge[1])

            # Node has been visited so it can be removed from the list
            unvisited_nodes.remove(min_node)
